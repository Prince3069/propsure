import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../../core/constants/app_theme.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../providers/app_providers.dart';
import '../../../data/models/chat_model.dart';

class ChatListScreen extends ConsumerWidget {
  const ChatListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userId = ref.watch(currentUserIdProvider);
    if (userId == null) return _GuestView();

    final chatsAsync = ref.watch(userChatsProvider(userId));

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: Text('Messages', style: GoogleFonts.syne(fontSize: 18, fontWeight: FontWeight.w700)),
        actions: [
          IconButton(icon: const Icon(Icons.search_rounded), onPressed: () {}),
        ],
      ),
      body: chatsAsync.when(
        data: (chats) {
          if (chats.isEmpty) {
            return EmptyState(
              icon: Icons.chat_bubble_outline_rounded,
              title: 'No messages yet',
              subtitle: 'When you contact an agent about a property, your conversations will appear here.',
              action: TextButton(onPressed: () => context.push('/search'), child: const Text('Browse Properties')),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.symmetric(vertical: 8),
            itemCount: chats.length,
            separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
            itemBuilder: (ctx, i) => _ChatTile(chat: chats[i], userId: userId),
          );
        },
        loading: () => ListView.separated(
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: 6,
          separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
          itemBuilder: (_, __) => const _ChatTileSkeleton(),
        ),
        error: (e, _) => Center(child: Text('Error: $e')),
      ),
    );
  }
}

class _GuestView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Messages', style: GoogleFonts.syne(fontSize: 18, fontWeight: FontWeight.w700))),
      body: EmptyState(
        icon: Icons.chat_bubble_outline_rounded,
        title: 'Your messages',
        subtitle: 'Sign in to chat with agents and landlords about properties.',
        action: ElevatedButton(
          onPressed: () => context.push('/auth?redirect=/messages'),
          child: const Text('Sign In'),
        ),
      ),
    );
  }
}

class _ChatTile extends StatelessWidget {
  final ChatModel chat;
  final String userId;
  const _ChatTile({required this.chat, required this.userId});

  @override
  Widget build(BuildContext context) {
    final otherId = chat.participantIds.firstWhere((id) => id != userId, orElse: () => userId);
    final otherName = chat.participantNames[otherId] ?? 'Agent';
    final otherPhoto = chat.participantPhotos[otherId];
    final unread = chat.unreadCounts[userId] ?? 0;
    final lastMsg = chat.lastMessage;
    final isMe = lastMsg?.senderId == userId;

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      leading: Stack(clipBehavior: Clip.none, children: [
        CircleAvatar(
          radius: 26,
          backgroundColor: AppColors.primaryPale2,
          backgroundImage: otherPhoto != null && otherPhoto.isNotEmpty ? NetworkImage(otherPhoto) : null,
          child: otherPhoto == null || otherPhoto.isEmpty
              ? Text(otherName.isNotEmpty ? otherName[0].toUpperCase() : '?',
                  style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 18))
              : null,
        ),
        Positioned(bottom: 0, right: 0,
          child: Container(width: 12, height: 12,
            decoration: BoxDecoration(color: AppColors.success, shape: BoxShape.circle,
              border: Border.all(color: AppColors.surface, width: 2)))),
      ]),
      title: Row(children: [
        Expanded(child: Text(otherName,
          style: TextStyle(fontWeight: unread > 0 ? FontWeight.w800 : FontWeight.w600, fontSize: 14, color: AppColors.text))),
        if (lastMsg != null)
          Text(timeago.format(lastMsg.createdAt),
            style: TextStyle(fontSize: 11, color: unread > 0 ? AppColors.primary : AppColors.text3,
              fontWeight: unread > 0 ? FontWeight.w700 : FontWeight.w400)),
      ]),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 2),
        if (chat.listingTitle != null)
          Text(chat.listingTitle!, style: const TextStyle(fontSize: 10, color: AppColors.primary, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
        Row(children: [
          if (isMe) const Text('You: ', style: TextStyle(fontSize: 12, color: AppColors.text3)),
          Expanded(child: Text(
            lastMsg?.isDeleted == true ? 'Message deleted' : (lastMsg?.text ?? ''),
            style: TextStyle(fontSize: 12, color: unread > 0 ? AppColors.text : AppColors.text3,
              fontWeight: unread > 0 ? FontWeight.w600 : FontWeight.w400,
              fontStyle: lastMsg?.isDeleted == true ? FontStyle.italic : FontStyle.normal),
            maxLines: 1, overflow: TextOverflow.ellipsis)),
          if (unread > 0) ...[
            const SizedBox(width: 8),
            Container(
              width: 20, height: 20,
              decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
              child: Center(child: Text('$unread', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)))),
          ],
        ]),
      ]),
      onTap: () => context.push('/chat/${chat.id}'),
    );
  }
}

class _ChatTileSkeleton extends StatelessWidget {
  const _ChatTileSkeleton();
  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      leading: const CircleAvatar(radius: 26, backgroundColor: AppColors.bg),
      title: Container(height: 12, width: 120, color: AppColors.bg),
      subtitle: Padding(padding: const EdgeInsets.only(top: 6),
        child: Container(height: 10, color: AppColors.bg)),
    );
  }
}
