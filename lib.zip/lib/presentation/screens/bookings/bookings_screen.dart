import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../../core/constants/app_theme.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/widgets/common_widgets.dart';
import '../../providers/app_providers.dart';
import '../../../data/repositories/booking_repository.dart';

class BookingsScreen extends ConsumerWidget {
  const BookingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userId = ref.watch(currentUserIdProvider) ?? '';
    final user = ref.watch(currentUserModelProvider).value;
    final isAgent = user?.role == AppConstants.roleAgent || user?.role == AppConstants.roleLandlord;

    return DefaultTabController(
      length: isAgent ? 2 : 1,
      child: Scaffold(
        backgroundColor: AppColors.bg,
        appBar: AppBar(
          title: Text('Bookings', style: GoogleFonts.syne(fontWeight: FontWeight.w700)),
          bottom: isAgent
              ? const TabBar(
                  tabs: [Tab(text: 'My Requests'), Tab(text: 'Incoming')],
                  indicatorColor: AppColors.primary,
                  labelColor: AppColors.primary,
                  unselectedLabelColor: AppColors.text3,
                )
              : null,
        ),
        body: isAgent
            ? TabBarView(children: [
                _BookingList(userId: userId, isAgentView: false),
                _BookingList(userId: userId, isAgentView: true),
              ])
            : _BookingList(userId: userId, isAgentView: false),
      ),
    );
  }
}

class _BookingList extends ConsumerWidget {
  final String userId;
  final bool isAgentView;
  const _BookingList({required this.userId, required this.isAgentView});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stream = isAgentView
        ? ref.watch(agentBookingsProvider(userId))
        : ref.watch(userBookingsProvider(userId));

    return stream.when(
      data: (bookings) {
        final typed = bookings.cast<BookingModel>();
        if (typed.isEmpty) {
          return EmptyState(
            icon: Icons.calendar_today_outlined,
            title: isAgentView ? 'No incoming requests' : 'No bookings yet',
            subtitle: isAgentView
                ? 'Inspection requests from tenants will show here.'
                : 'Book an inspection from any property listing.',
            action: isAgentView ? null : TextButton(
              onPressed: () => context.push('/search'),
              child: const Text('Browse Properties'),
            ),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(14),
          itemCount: typed.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (ctx, i) => _BookingCard(booking: typed[i], isAgentView: isAgentView),
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('Error: $e')),
    );
  }
}

class _BookingCard extends StatelessWidget {
  final BookingModel booking;
  final bool isAgentView;
  const _BookingCard({required this.booking, required this.isAgentView});

  @override
  Widget build(BuildContext context) {
    final configs = {
      'pending': (AppColors.statusPending, const Color(0xFFFEF3C7), '⏳'),
      'confirmed': (AppColors.success, const Color(0xFFDCFCE7), '✅'),
      'completed': (AppColors.text2, AppColors.bg, '🏁'),
      'cancelled': (AppColors.error, const Color(0xFFFEE2E2), '❌'),
      'rejected': (AppColors.error, const Color(0xFFFEE2E2), '🚫'),
    };
    final (fg, bg, icon) = configs[booking.status] ?? (AppColors.text3, AppColors.bg, '❓');

    final dt = booking.dateTime;
    final months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    final h = dt.hour > 12 ? dt.hour - 12 : dt.hour;
    final m = dt.minute.toString().padLeft(2, '0');
    final period = dt.hour >= 12 ? 'PM' : 'AM';
    final dateStr = '${dt.day} ${months[dt.month - 1]} · $h:$m $period';

    return GestureDetector(
      onTap: () => context.push('/booking/${booking.id}'),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: booking.status == AppConstants.bookingPending ? AppColors.statusPending.withOpacity(0.3) : AppColors.border),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(booking.listingTitle,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.text),
              maxLines: 1, overflow: TextOverflow.ellipsis)),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
              decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(99)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Text(icon, style: const TextStyle(fontSize: 10)),
                const SizedBox(width: 4),
                Text(booking.status.toUpperCase(),
                  style: TextStyle(color: fg, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: 0.4)),
              ]),
            ),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            const Icon(Icons.calendar_today_outlined, size: 13, color: AppColors.text3),
            const SizedBox(width: 5),
            Text(dateStr, style: const TextStyle(fontSize: 12, color: AppColors.text2)),
            const SizedBox(width: 14),
            const Icon(Icons.person_outline_rounded, size: 13, color: AppColors.text3),
            const SizedBox(width: 5),
            Expanded(child: Text(
              isAgentView ? booking.userName : booking.agentName,
              style: const TextStyle(fontSize: 12, color: AppColors.text2),
              maxLines: 1, overflow: TextOverflow.ellipsis)),
          ]),
          if (booking.message != null && booking.message!.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(booking.message!, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11, color: AppColors.text3, fontStyle: FontStyle.italic)),
          ],
          const SizedBox(height: 8),
          Row(children: [
            Text(timeago.format(booking.createdAt), style: const TextStyle(fontSize: 10, color: AppColors.text3)),
            const Spacer(),
            const Text('View details →', style: TextStyle(fontSize: 11, color: AppColors.primary, fontWeight: FontWeight.w700)),
          ]),
        ]),
      ),
    );
  }
}
